/******************************************************************************/
				README					
JTime Manager is a small timer application designed to keep the time used in
any activity, it was designed specially for developers who need to take time records
of their project assignments like design time, build time, testing time, etc.

Author: Eduardo Vidal

Copyright C 2011
This software is Free Software and it's under the terms and conditions of the GNU GPL 3.0 License.

CHANGELOG
JTime Manager 1.5.3
-Redefined configuration window.
-Bigger character limit for tab's name.
-More options to configure UI behaviour.
-New mini GUI mode allow to keep the timer on small area.
-Open JTimeManager  on different location bugfix.

Installation:
This software is standalone and doesn't require to be installed just run the application.

To Run the application:
To run this application you need to have java 1.5 or higher, to get it just go to the site java.com and download it, if you are using linux, you can look for the JRE pacakges with your pacakge manager.

For all users:

IMPORTANT NOTICE:
Don't move the file JTimeManager.jar to another directory without the libs folder, it is IMPORTANT to execute the jar file on the same directory as the lib folder.

If you are in the same directory as the application just type java -jar "JTimeManager.jar"

For Windows users:
dobule click on the stand alone JAR file to run it, or from cmd type java -jar "yourPathToTheFile\JTimeManager\JTimeManager.jar"

For Linux/Unix/OSX users:
run the JAR file from console typing
java -jar "yourPathToTheFile/JTimeManager/JTimeManager.jar" 
Or run the shell file JTimeManager.sh on the same directory as the jar file.


